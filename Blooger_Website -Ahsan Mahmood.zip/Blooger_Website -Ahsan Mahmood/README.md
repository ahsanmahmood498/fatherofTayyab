# Blooger_Website
This is the complete blooger website create using html and css
